package com.maven.madaduser.User

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
