class Provider{
  final String name;
  final String address;

  Provider({
    required this.name,
    required this.address,
  });
}
