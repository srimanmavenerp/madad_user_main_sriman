import 'package:get/get.dart';
import 'package:madaduser/utils/core_export.dart';
import 'package:madaduser/feature/create_post/widget/custom_date_picker.dart';
import 'package:madaduser/feature/create_post/widget/custom_time_picker.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

class CustomDateTimePicker extends StatelessWidget {
  final bool Function(DateTime)? isDateAllowed;
  final bool Function(TimeOfDay)? isTimeAllowed;
  final String serviceId;

  static const String restrictedServiceId =
      'a0e54890-a389-4a32-b5ce-e0959cb6ef14';

  const CustomDateTimePicker({
    super.key,
    this.isDateAllowed,
    this.isTimeAllowed,
    required this.serviceId,
  });

  @override
  Widget build(BuildContext context) {
    if (ResponsiveHelper.isDesktop(context)) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(Dimensions.radiusExtraLarge),
        ),
        insetPadding: const EdgeInsets.all(30),
        clipBehavior: Clip.antiAliasWithSaveLayer,
        child: pointerInterceptor(),
      );
    }
    return pointerInterceptor();
  }

  Widget pointerInterceptor() {
    Get.find<ScheduleController>().setInitialScheduleValue();
    ConfigModel configModel = Get.find<SplashController>().configModel;
    var dateRangePickerController = DateRangePickerController();

    return Container(
      width: ResponsiveHelper.isDesktop(Get.context!)
          ? Dimensions.webMaxWidth / 2
          : Dimensions.webMaxWidth,
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(Dimensions.radiusLarge),
          topRight: Radius.circular(Dimensions.radiusLarge),
        ),
        color: Theme.of(Get.context!).cardColor,
      ),
      padding: const EdgeInsets.all(15),
      child: GetBuilder<ScheduleController>(builder: (scheduleController) {
        return SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: Dimensions.paddingSizeDefault),
              Container(
                decoration: BoxDecoration(
                  color: Theme.of(Get.context!).hintColor,
                  borderRadius: BorderRadius.circular(15),
                ),
                height: 4,
                width: 80,
              ),
              const SizedBox(height: Dimensions.paddingSizeSmall),

              /// Custom Date Picker
              CustomDatePicker(
                dateRangePickerController: dateRangePickerController,
                selectableDayPredicate: (date) =>
                    Get.find<ScheduleController>().isDateAllowed(date),
              ),

              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: ResponsiveHelper.isDesktop(Get.context!)
                      ? Dimensions.paddingSizeLarge * 2
                      : 0,
                ),
                child: CustomTimePicker(
                  isTimeAllowed: (time) =>
                      Get.find<ScheduleController>().isTimeAllowed(time),
                  serviceId: serviceId,
                ),
              ),

              if (configModel.content?.instantBooking == 1)
                Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: ResponsiveHelper.isDesktop(Get.context!)
                        ? Dimensions.paddingSizeLarge * 2
                        : 0,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: Dimensions.paddingSizeExtraSmall),
                      Divider(
                        color: Theme.of(Get.context!).hintColor,
                        height: 0.5,
                      ),
                      const SizedBox(height: Dimensions.paddingSizeSmall),
                    ],
                  ),
                ),

              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: ResponsiveHelper.isDesktop(Get.context!)
                      ? Dimensions.paddingSizeLarge * 3
                      : 0,
                ),
                child: actionButtonWidget(Get.context!, scheduleController),
              ),
            ],
          ),
        );
      }),
    );
  }

  Row actionButtonWidget(
      BuildContext context, ScheduleController scheduleController) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        TextButton(
          style: TextButton.styleFrom(
            padding: EdgeInsets.zero,
            minimumSize: const Size(50, 30),
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
          onPressed: () {
            CartController cartController = Get.find();
            cartController.tempText.value = ''; // clear temp text
            Get.back();
          },
          child: Text(
            'cancel'.tr.toUpperCase(),
            style: robotoMedium.copyWith(
              color: Get.isDarkMode
                  ? Theme.of(context).primaryColorLight
                  : Colors.black.withOpacity(0.6),
            ),
          ),
        ),
        const SizedBox(width: Dimensions.paddingSizeDefault),
        Obx(() {
          final cartController = Get.find<CartController>();
          final scheduleController = Get.find<ScheduleController>();

          // Check if cart contains restricted service
          final hasRestrictedService = cartController.cartList.any((item) =>
              item.service?.id == CustomTimePicker.restrictedServiceId);

          // Button is enabled if tempText is not empty OR restricted service logic
          final isButtonEnabled = cartController.tempText.value.isNotEmpty ||
              serviceId == CustomTimePicker.restrictedServiceId ||
              hasRestrictedService;

          return CustomButton(
            width: ResponsiveHelper.isDesktop(context) ? 90 : 70,
            height: ResponsiveHelper.isDesktop(context) ? 45 : 40,
            radius: Dimensions.radiusExtraMoreLarge,
            buttonText: "ok".tr.toUpperCase(),
            onPressed: isButtonEnabled
                ? () {
                    // Your existing onPressed logic here
                    ConfigModel config =
                        Get.find<SplashController>().configModel;

                    // Restricted service validation
                    if (serviceId == CustomTimePicker.restrictedServiceId ||
                        hasRestrictedService) {
                      String selectedTimeStr = scheduleController.selectedTime!;
                      String selectedDateStr = scheduleController.selectedDate!;

                      TimeOfDay selectedTime =
                          _convertStringToTimeOfDay(selectedTimeStr);
                      DateTime selectedDate = DateTime.parse(selectedDateStr);

                      if (!_isBookingValid(selectedTime, selectedDate)) {
                        customSnackBar(
                          'Selected time must be between 8 AM and 10 PM, and at least 1 hour ahead.'
                              .tr,
                          showDefaultSnackBar: false,
                        );
                        return;
                      }
                    }

                    if (scheduleController.initialSelectedScheduleType ==
                        null) {
                      customSnackBar(
                        'select_your_preferable_booking_time'.tr,
                        showDefaultSnackBar: false,
                      );
                    } else {
                      // Update the schedule
                      scheduleController.buildSchedule(
                          scheduleType:
                              scheduleController.selectedScheduleType);

                      // Update tempText in CartController
                      String displayText =
                          DateConverter.dateMonthYearTimeTwentyFourFormat(
                              DateConverter.dateTimeStringToDate(
                                  scheduleController.scheduleTime!));

                      cartController.tempText.value = displayText;

                      Get.back();
                    }
                  }
                : null, // disabled if conditions not met
          );
        })
      ],
    );
  }

  TimeOfDay _convertStringToTimeOfDay(String timeString) {
    final parts = timeString.split(':');
    final hour = int.parse(parts[0]);
    final minute = int.parse(parts[1]);
    return TimeOfDay(hour: hour, minute: minute);
  }

  bool _isBookingValid(TimeOfDay selectedTime, DateTime selectedDate) {
    final startTime = TimeOfDay(hour: 8, minute: 0);
    final endTime = TimeOfDay(hour: 22, minute: 0);

    if (!_isTimeInRange(selectedTime, startTime, endTime)) {
      return false;
    }

    final now = DateTime.now();

    final selectedDateTime = DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
      selectedTime.hour,
      selectedTime.minute,
    );

    // Only apply 1-hour rule if selected date is today
    if (selectedDate.year == now.year &&
        selectedDate.month == now.month &&
        selectedDate.day == now.day) {
      return selectedDateTime.isAfter(now.add(const Duration(hours: 1)));
    }

    // If future date, only check if in range (already done above)
    return true;
  }

  bool _isTimeInRange(TimeOfDay time, TimeOfDay start, TimeOfDay end) {
    final t = Duration(hours: time.hour, minutes: time.minute);
    final s = Duration(hours: start.hour, minutes: start.minute);
    final e = Duration(hours: end.hour, minutes: end.minute);
    return t >= s && t <= e;
  }
}
