import 'package:intl/intl.dart';
import 'package:madaduser/feature/create_post/widget/custom_date_time_picker.dart';
import 'package:get/get.dart';
import 'package:madaduser/utils/core_export.dart';

class ServiceSchedule extends StatefulWidget {
  const ServiceSchedule({super.key});

  @override
  State<ServiceSchedule> createState() => _ServiceScheduleState();
}

class _ServiceScheduleState extends State<ServiceSchedule> {
  // Cache controllers once
  late final CartController cartController;
  late final ScheduleController scheduleController;

  @override
  void initState() {
    super.initState();

    // Initialize controllers
    cartController = Get.find<CartController>();
    scheduleController = Get.find<ScheduleController>();

    // Debug prints
    print("ServiceSchedule Page: initState called");
    print("CartController items count: ${cartController.cartList.length}");
    print(
        "ScheduleController selectedScheduleType: ${scheduleController.selectedScheduleType}");
    print(
        "ScheduleController selectedTime: ${scheduleController.scheduleTime}");
  }

  @override
  Widget build(BuildContext context) {
    // Use a single GetBuilder for both controllers
    return GetBuilder<CartController>(
      builder: (_) {
        return GetBuilder<ScheduleController>(
          builder: (_) {
            // You can also wrap the Column with Obx if controllers have Rx values
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: Dimensions.paddingSizeLarge),
                Text(
                  "preferable_time".tr,
                  style: robotoMedium.copyWith(
                      fontSize: Dimensions.fontSizeDefault),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                GestureDetector(
                  onTap: () async {
                    // 1️⃣ Check if schedule booking is available
                    String? errorText =
                        cartController.checkScheduleBookingAvailability();
                    if (errorText != null) {
                      customSnackBar(errorText.tr);
                      return;
                    }

                    // 2️⃣ Show a temporary loading dialog while fetching data
                    Get.dialog(
                      const Center(child: CircularProgressIndicator()),
                      barrierDismissible: false,
                    );

                    try {
                      // 3️⃣ Ensure cart is loaded
                      await cartController.getCartListFromServer();

                      // Optionally, you can refresh schedule if needed
                      scheduleController.buildSchedule(
                        scheduleType: ScheduleType.asap,
                        shouldUpdate: true,
                      );

                      // 4️⃣ Close the loading dialog
                      if (Get.isDialogOpen ?? false) Get.back();

                      // 5️⃣ Open the bottom sheet with fully loaded data
                      showModalBottomSheet(
                        isDismissible: false,
                        backgroundColor: Colors.transparent,
                        isScrollControlled: true,
                        enableDrag: false,
                        context: context,
                        builder: (BuildContext context) {
                          return CustomDateTimePicker(
                            isDateAllowed: (date) =>
                                scheduleController.isDateAllowed(date),
                            isTimeAllowed: (time) =>
                                scheduleController.isTimeAllowed(time),
                            serviceId: cartController.cartList.isNotEmpty
                                ? cartController.cartList[0].serviceId
                                : '',
                          );
                        },
                      );
                    } catch (e) {
                      // 6️⃣ Handle errors and close loader
                      if (Get.isDialogOpen ?? false) Get.back();
                      customSnackBar("error_loading_data".tr);
                      debugPrint("Error fetching cart/schedule: $e");
                    }
                  },
                  child: Container(
                    width: Get.width,
                    padding: const EdgeInsets.symmetric(
                      horizontal: Dimensions.paddingSizeDefault,
                      vertical: Dimensions.paddingSizeSmall,
                    ),
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(Dimensions.radiusSeven),
                      border: Border.all(
                        color: Theme.of(context).primaryColor.withOpacity(0.3),
                        width: 0.5,
                      ),
                      color: Theme.of(context).cardColor,
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(Dimensions.radiusSeven),
                        border: Border.all(
                          color:
                              Theme.of(context).primaryColor.withOpacity(0.3),
                          width: 0.5,
                        ),
                        color: Theme.of(context).hoverColor.withOpacity(0.5),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: Dimensions.paddingSizeDefault,
                        vertical: Dimensions.paddingSizeSmall,
                      ),
                      child: Center(
                        child: Row(
                          children: [
                            Expanded(
                              flex: 7,
                              child: Row(
                                children: [
                                  Obx(() {
                                    final cartController =
                                        Get.find<CartController>();
                                    final scheduleController =
                                        Get.find<ScheduleController>();

                                    String displayText;

                                    if (cartController
                                        .tempText.value.isNotEmpty) {
                                      // Try to parse tempText into DateTime
                                      DateTime? tempDate;
                                      try {
                                        tempDate = DateTime.tryParse(
                                                cartController
                                                    .tempText.value) ??
                                            DateFormat('yyyy-MM-dd HH:mm:ss')
                                                .parse(cartController
                                                    .tempText.value);
                                      } catch (_) {
                                        tempDate = null;
                                      }

                                      // Format with day, month, year + time
                                      displayText = tempDate != null
                                          ? DateFormat('dd MMM yyyy, hh:mm a')
                                              .format(tempDate)
                                          : cartController.tempText.value;
                                    } else {
                                      // Fallback to scheduleController values
                                      displayText = scheduleController
                                                  .selectedScheduleType ==
                                              ScheduleType.schedule
                                          ? "select_schedule_time".tr
                                          : (scheduleController.scheduleTime !=
                                                  null
                                              ? DateFormat(
                                                      'dd MMM yyyy, hh:mm a')
                                                  .format(DateConverter
                                                      .dateTimeStringToDate(
                                                          scheduleController
                                                              .scheduleTime!))
                                              : "select_schedule_time".tr);
                                    }

                                    return Text(
                                      displayText,
                                      style: robotoMedium,
                                    );
                                  })
                                ],
                              ),
                            ),
                            Image.asset(
                              Images.scheduleIcon,
                              width: 20,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: Dimensions.paddingSizeDefault),
              ],
            );
          },
        );
      },
    );
  }
}
