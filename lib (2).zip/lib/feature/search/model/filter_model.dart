import 'package:madaduser/utils/core_export.dart';

class FilterModel {
  String? title;
  AllFilterType? type;

  FilterModel({this.title, this.type});
}