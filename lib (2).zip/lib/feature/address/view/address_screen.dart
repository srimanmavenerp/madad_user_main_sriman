/*
import 'package:get/get.dart';
import 'package:madaduser/utils/core_export.dart';

class AddressScreen extends StatefulWidget {
  final String? fromPage;
  const AddressScreen({super.key, this.fromPage}) ;

  @override
  State<AddressScreen> createState() => _AddressScreenState();
}


class _AddressScreenState extends State<AddressScreen> {

  @override
  void initState() {
    super.initState();
    Get.find<LocationController>().getAddressList(fromCheckout: widget.fromPage=="checkout"?true:false);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'my_address'.tr),
      endDrawer:ResponsiveHelper.isDesktop(context) ? const MenuDrawer():null,

      body: GetBuilder<LocationController>(
          builder: (locationController) {
            List<AddressModel>? addressList = locationController.addressList;
            List<AddressModel>? zoneBasedAddress = [];
            if(addressList != null && addressList.isNotEmpty ){
              zoneBasedAddress =  addressList.where((element) =>
              element.zoneId == Get.find<LocationController>().getUserAddress()?.zoneId).toList();
            }
            if(widget.fromPage == "checkout"){
              addressList = zoneBasedAddress;
            }

            AddressModel? addressModel;
            addressModel = locationController.getUserAddress();


            if(locationController.addressList!=null){
              return FooterBaseView(
                  isCenter: (addressList == null || addressList.isEmpty),
                  child: WebShadowWrap(
                    child: Column(
                      children: [
                        ResponsiveHelper.isDesktop(context) ?
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            CustomButton(
                              width: 200,
                              buttonText: 'add_new_address'.tr,
                              onPressed: () => Get.toNamed(RouteHelper.getAddAddressRoute(widget.fromPage == 'checkout' ? true : false)),
                            ),
                          ],
                        ): const SizedBox(),
                        const SizedBox(height: Dimensions.paddingSizeDefault,),

                        addressList!.isNotEmpty ?
                        RefreshIndicator(
                          onRefresh: () async {
                            await locationController.getAddressList();
                          },
                          child: SizedBox(
                            width: Dimensions.webMaxWidth,
                            child: (addressList.isNotEmpty)?
                            GridView.builder(
                              physics: const NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: ResponsiveHelper.isMobile(context) ?  1 :  2,
                                childAspectRatio:ResponsiveHelper.isMobile(context) ?  4 : 6,
                                crossAxisSpacing: Dimensions.paddingSizeExtraLarge,
                                mainAxisExtent: Dimensions.addressItemHeight,
                                mainAxisSpacing:ResponsiveHelper.isDesktop(context) || ResponsiveHelper.isTab(context) ? Dimensions.paddingSizeExtraLarge: 2.0,
                              ),

                              padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                              itemCount: addressList.length,
                              itemBuilder: (context, index) {
                                return
                                  AddressWidget(
                                    selectedUserAddressId: addressModel?.id,
                                    address: addressList![index],
                                    fromAddress: true,
                                    fromCheckout: widget.fromPage == 'checkout' ? true : false,

                                    onTap: () async {
                                      if(widget.fromPage == 'checkout'){
                                        if(isRedundentClick(DateTime.now())){
                                          return;
                                        }
                                        Get.dialog(const CustomLoader(),barrierDismissible: false);
                                        await locationController.setAddressIndex(addressList![index]).then((isSuccess){
                                          Get.back();
                                          if(!isSuccess){
                                            customSnackBar('this_service_not_available'.tr);
                                          }
                                        });
                                        Get.back();
                                      }
                                    },

                                    onEditPressed: () {
                                      Get.toNamed(
                                          RouteHelper.getEditAddressRoute(addressList![index], false));
                                    },
                                    onRemovePressed: () {
                                      if (Get.isSnackbarOpen) {
                                        Get.back();
                                      }
                                      Get.dialog(ConfirmationDialog(
                                        icon: Images.warning,
                                        description: 'are_you_sure_want_to_delete_address'.tr,
                                        onYesPressed: () {
                                          Navigator.of(context).pop();

                                          Get.dialog(
                                            const CustomLoader(), barrierDismissible: false,
                                          );
                                          locationController.deleteUserAddressByID(addressList![index],
                                          ).then((response) {
                                            Get.back();
                                            customSnackBar(response.message!.tr.capitalizeFirst,type : ToasterMessageType.success);
                                          });
                                        },
                                      ));
                                    },
                                  );
                              },
                            ): const SizedBox(),
                          ),
                        ) :
                        SizedBox(height: Get.height*0.6,child: Center(child: NoDataScreen(text: 'no_address_found'.tr,type: NoDataType.address,))),
                      ],
                    ),
                  ));
            }else{
              return const Center(child: CircularProgressIndicator(),);
            }
          }),

      floatingActionButton: (!ResponsiveHelper.isDesktop(context) &&  Get.find<AuthController>().isLoggedIn()) ?  GestureDetector(
        child: Container(
            decoration: BoxDecoration(
                boxShadow:Get.isDarkMode ? null: shadow,
                color: Theme.of(context).colorScheme.primary,
                borderRadius: BorderRadius.circular(Dimensions.radiusExtraMoreLarge)
            ),
            height: Dimensions.addAddressHeight,
            width: Dimensions.addAddressWidth,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.add, color: Colors.white,size: 20,),
                const SizedBox(width: Dimensions.paddingSizeExtraSmall,),
                Text('add_new_address'.tr,style: robotoMedium.copyWith(
                    fontSize: Dimensions.fontSizeDefault,
                    color: Theme.of(context).primaryColorLight),),
              ],
            )),
        onTap:() {
          Get.toNamed(RouteHelper.getAddAddressRoute(widget.fromPage == 'checkout' ? true : false));
        },
      ) : null,
    );
  }
}



// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get_storage/get_storage.dart';
// import 'package:madaduser/utils/core_export.dart';
// import '../../TypesofCarwash/TypesOfCarWash_controller.dart';
// import '../../vehicle/vehicle/controller/vehicle_controller.dart';
//
// class AddressScreen extends StatefulWidget {
//   final String? fromPage;
//   final String? serviceId;
//   final String? subCategoryId;
//   final String? categoryId;
//   const AddressScreen({
//     super.key,
//     this.fromPage,
//     this.serviceId,
//     this.subCategoryId,
//     this.categoryId,
//   });
//
//   @override
//   State<AddressScreen> createState() => _AddressScreenState();
// }
//
// class _AddressScreenState extends State<AddressScreen> {
//   final GetStorage _storage = GetStorage();
//   String? _serviceId;
//   String? _subCategoryId;
//   String? _categoryId;
//   late final TypesOfCarWashController _typesController;
//
//   // final TypesOfCarWashController _typesController = Get.find<TypesOfCarWashController>();   ///////// Balu
//
//   @override
//   void initState() {
//     super.initState();
//     _initializeData();
//   }
//
//   Future<void> _initializeData() async {
//     // First ensure types controller has data
//     if (_typesController.typesOfCarWash.value == null) {
//       await _typesController.loadInitialData();
//     }
//
//     // Then load our arguments
//     await _loadArguments();
//
//     // Finally get address list
//     Get.find<LocationController>().getAddressList(
//       fromCheckout: widget.fromPage == "checkout" ? true : false,
//     );
//   }
//
//   Future<void> _loadArguments() async {
//     final Map<String, dynamic>? arguments = Get.arguments;
//
//     // Get service ID from TypesOfCarWashController as primary source
//     final controllerServiceId = _typesController.getPrimaryServiceId();
//     print('Service ID from TypesController: $controllerServiceId');
//
//     _serviceId = controllerServiceId?.isNotEmpty ?? false
//         ? controllerServiceId
//         : widget.serviceId?.isNotEmpty ?? false
//         ? widget.serviceId
//         : arguments?['serviceId']?.isNotEmpty ?? false
//         ? arguments!['serviceId']
//         : _storage.read('serviceId')?.isNotEmpty ?? false
//         ? _storage.read('serviceId')
//         : null;
//
//     _subCategoryId = widget.subCategoryId?.isNotEmpty ?? false
//         ? widget.subCategoryId
//         : arguments?['subCategoryId']?.isNotEmpty ?? false
//         ? arguments!['subCategoryId']
//         : _storage.read('subCategoryId')?.isNotEmpty ?? false
//         ? _storage.read('subCategoryId')
//         : null;
//
//     _categoryId = widget.categoryId?.isNotEmpty ?? false
//         ? widget.categoryId
//         : arguments?['categoryId']?.isNotEmpty ?? false
//         ? arguments!['categoryId']
//         : _storage.read('categoryId')?.isNotEmpty ?? false
//         ? _storage.read('categoryId')
//         : null;
//
//     // Validate we have a service ID
//     if (_serviceId == null || _serviceId!.isEmpty) {
//       print('Warning: No service ID found from any source!');
//     }
//
//     // Store IDs in VehicleController for persistence
//     Get.find<VehicleController>().setServiceArguments(
//       _serviceId ?? '',
//       _subCategoryId ?? '',
//       _categoryId ?? '',
//     );
//
//     // Store IDs in GetStorage for additional persistence
//     if (_serviceId != null) _storage.write('serviceId', _serviceId);
//     if (_subCategoryId != null) _storage.write('subCategoryId', _subCategoryId);
//     if (_categoryId != null) _storage.write('categoryId', _categoryId);
//
//     print('Final arguments: '
//         'serviceId=$_serviceId, '
//         'subCategoryId=$_subCategoryId, '
//         'categoryId=$_categoryId');
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: CustomAppBar(title: 'my_address'.tr),
//       endDrawer: ResponsiveHelper.isDesktop(context) ? const MenuDrawer() : null,
//       body: GetBuilder<LocationController>(
//         builder: (locationController) {
//           List<AddressModel>? addressList = locationController.addressList;
//           List<AddressModel>? zoneBasedAddress = [];
//
//           if (addressList != null && addressList.isNotEmpty) {
//             zoneBasedAddress = addressList.where((element) =>
//             element.zoneId == Get.find<LocationController>().getUserAddress()?.zoneId).toList();
//           }
//
//           if (widget.fromPage == "checkout") {
//             addressList = zoneBasedAddress;
//           }
//
//           AddressModel? addressModel;
//           addressModel = locationController.getUserAddress();
//
//           if (locationController.addressList != null) {
//             return FooterBaseView(
//               isCenter: (addressList == null || addressList.isEmpty),
//               child: WebShadowWrap(
//                 child: Column(
//                   children: [
//                     if (ResponsiveHelper.isDesktop(context))
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.end,
//                         children: [
//                           CustomButton(
//                             width: 200,
//                             buttonText: 'add_new_address'.tr,
//                             onPressed: () => Get.toNamed(
//                               RouteHelper.getAddAddressRoute(widget.fromPage == 'checkout'),
//                               arguments: {
//                                 'serviceId': _serviceId,
//                                 'subCategoryId': _subCategoryId,
//                                 'categoryId': _categoryId,
//                               },
//                             ),
//                           ),
//                         ],
//                       ),
//                     const SizedBox(height: Dimensions.paddingSizeDefault),
//                     addressList!.isNotEmpty
//                         ? RefreshIndicator(
//                       onRefresh: () async {
//                         await locationController.getAddressList();
//                       },
//                       child: SizedBox(
//                         width: Dimensions.webMaxWidth,
//                         child: GridView.builder(
//                           physics: const NeverScrollableScrollPhysics(),
//                           shrinkWrap: true,
//                           gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//                             crossAxisCount: ResponsiveHelper.isMobile(context) ? 1 : 2,
//                             childAspectRatio: ResponsiveHelper.isMobile(context) ? 4 : 6,
//                             crossAxisSpacing: Dimensions.paddingSizeExtraLarge,
//                             mainAxisExtent: Dimensions.addressItemHeight,
//                             mainAxisSpacing: ResponsiveHelper.isDesktop(context) ||
//                                 ResponsiveHelper.isTab(context)
//                                 ? Dimensions.paddingSizeExtraLarge
//                                 : 2.0,
//                           ),
//                           padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
//                           itemCount: addressList.length,
//                           itemBuilder: (context, index) {
//                             AddressModel currentAddress = addressList![index];
//
//                             return AddressWidget(
//                               selectedUserAddressId: addressModel?.id,
//                               address: addressList![index],
//                               fromAddress: true,
//                               fromCheckout: widget.fromPage == 'checkout',
//                               onTap: () async {
//                                 if (isRedundentClick(DateTime.now())) return;
//
//                                 Get.dialog(const CustomLoader(), barrierDismissible: false);
//
//                                 // Get the most current service ID before proceeding
//                                 final currentServiceId = _typesController.getPrimaryServiceId() ?? _serviceId;
//                                 _serviceId = currentServiceId;
//
//                                 await locationController
//                                     .setAddressIndex(currentAddress)
//                                     .then((isSuccess) {
//                                   Get.back();
//                                   if (isSuccess) {
//                                     if (widget.fromPage == 'checkout') {
//                                       print('Address selected for checkout with serviceId: $_serviceId');
//                                     } else {
//                                       Get.back(result: {
//                                         'success': true,
//                                         'serviceId': _serviceId,
//                                         'subCategoryId': _subCategoryId,
//                                         'categoryId': _categoryId,
//                                       });
//                                       print('Returning with serviceId: $_serviceId');
//                                     }
//                                   } else {
//                                     customSnackBar('this_service_not_available'.tr);
//                                   }
//                                 });
//                               },
//                               onEditPressed: () {
//                                 Get.toNamed(
//                                   RouteHelper.getEditAddressRoute(currentAddress, false),
//                                   arguments: {
//                                     'serviceId': _serviceId,
//                                     'subCategoryId': _subCategoryId,
//                                     'categoryId': _categoryId,
//                                   },
//                                 );
//                               },
//                               onRemovePressed: () {
//                                 if (Get.isSnackbarOpen) Get.back();
//
//                                 Get.dialog(ConfirmationDialog(
//                                   icon: Images.warning,
//                                   description: 'are_you_sure_want_to_delete_address'.tr,
//                                   onYesPressed: () {
//                                     Navigator.of(context).pop();
//                                     Get.dialog(const CustomLoader(),
//                                         barrierDismissible: false);
//                                     locationController
//                                         .deleteUserAddressByID(currentAddress)
//                                         .then((response) {
//                                       Get.back();
//                                       customSnackBar(
//                                         response.message!.tr.capitalizeFirst,
//                                         type: ToasterMessageType.success,
//                                       );
//                                     });
//                                   },
//                                 ));
//                               },
//                             );
//                           },
//                         ),
//                       ),
//                     )
//                         : SizedBox(
//                       height: Get.height * 0.6,
//                       child: Center(
//                         child: NoDataScreen(
//                           text: 'no_address_found'.tr,
//                           type: NoDataType.address,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           } else {
//             return const Center(child: CircularProgressIndicator());
//           }
//         },
//       ),
//       floatingActionButton: (!ResponsiveHelper.isDesktop(context) &&
//           Get.find<AuthController>().isLoggedIn())
//           ? GestureDetector(
//         onTap: () {
//           Get.toNamed(
//             RouteHelper.getAddAddressRoute(widget.fromPage == 'checkout'),
//             arguments: {
//               'serviceId': _serviceId,
//               'subCategoryId': _subCategoryId,
//               'categoryId': _categoryId,
//             },
//           );
//         },
//         child: Container(
//           decoration: BoxDecoration(
//             boxShadow: Get.isDarkMode ? null : shadow,
//             color: Theme.of(context).colorScheme.primary,
//             borderRadius: BorderRadius.circular(Dimensions.radiusExtraMoreLarge),
//           ),
//           height: Dimensions.addAddressHeight,
//           width: Dimensions.addAddressWidth,
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               const Icon(Icons.add, color: Colors.white, size: 20),
//               const SizedBox(width: Dimensions.paddingSizeExtraSmall),
//               Text(
//                 'add_new_address'.tr,
//                 style: robotoMedium.copyWith(
//                   fontSize: Dimensions.fontSizeDefault,
//                   color: Theme.of(context).primaryColorLight,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       )
//           : null,
//     );
//   }
// }
*/


import 'package:get/get.dart';
import 'package:madaduser/utils/core_export.dart';

class AddressScreen extends StatefulWidget {
  final String? fromPage;

  const AddressScreen({super.key, this.fromPage});

  @override
  State<AddressScreen> createState() => _AddressScreenState();
}

class _AddressScreenState extends State<AddressScreen> {
  String? _selectedAddressId;

  @override
  void initState() {
    super.initState();

    // Fetch address list
    Get.find<LocationController>().getAddressList(
      fromCheckout: widget.fromPage == "checkout" ? true : false,
    );

    // Set default selected address from controller
    final AddressModel? userAddress = Get.find<LocationController>().getUserAddress();
    _selectedAddressId = userAddress?.id?.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'my_address'.tr),
      endDrawer: ResponsiveHelper.isDesktop(context) ? const MenuDrawer() : null,

      body: GetBuilder<LocationController>(builder: (locationController) {
        List<AddressModel>? addressList = locationController.addressList;
        List<AddressModel> zoneBasedAddress = [];

        // Filter zone-based address for checkout
        if (addressList != null && addressList.isNotEmpty) {
          zoneBasedAddress = addressList
              .where((element) =>
          element.zoneId ==
              Get.find<LocationController>().getUserAddress()?.zoneId)
              .toList();
        }

        if (widget.fromPage == "checkout") {
          addressList = zoneBasedAddress;
        }

        if (addressList != null) {
          return FooterBaseView(
            isCenter: addressList.isEmpty,
            child: WebShadowWrap(
              child: Column(
                children: [
                  if (ResponsiveHelper.isDesktop(context))
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        CustomButton(
                          width: 200,
                          buttonText: 'add_new_address'.tr,
                          onPressed: () {
                            Get.toNamed(RouteHelper.getAddAddressRoute(
                                widget.fromPage == 'checkout'));
                          },
                        ),
                      ],
                    ),
                  const SizedBox(height: Dimensions.paddingSizeDefault),

                  addressList.isNotEmpty
                      ? RefreshIndicator(
                    onRefresh: () async {
                      await locationController.getAddressList();
                    },
                    child: SizedBox(
                      width: Dimensions.webMaxWidth,
                      child: GridView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        gridDelegate:
                        SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: ResponsiveHelper.isMobile(context) ? 1 : 2,
                          childAspectRatio: ResponsiveHelper.isMobile(context) ? 4 : 6,
                          crossAxisSpacing: Dimensions.paddingSizeExtraLarge,
                          mainAxisExtent: Dimensions.addressItemHeight,
                          mainAxisSpacing: ResponsiveHelper.isDesktop(context) ||
                              ResponsiveHelper.isTab(context)
                              ? Dimensions.paddingSizeExtraLarge
                              : 2.0,
                        ),
                        padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                        itemCount: addressList.length,
                        itemBuilder: (context, index) {
                          AddressModel address = addressList![index];

                          return AddressWidget(
                            selectedUserAddressId: _selectedAddressId,
                            address: address,
                            fromAddress: true,
                            fromCheckout: widget.fromPage == 'checkout',
                            onTap: () async {
                              setState(() {
                                _selectedAddressId = address.id?.toString();
                              });

                              // Handle checkout selection logic
                              if (widget.fromPage == 'checkout') {
                                if (isRedundentClick(DateTime.now())) return;

                                Get.dialog(const CustomLoader(), barrierDismissible: false);

                                await locationController
                                    .setAddressIndex(address)
                                    .then((isSuccess) {
                                  Get.back();
                                  if (!isSuccess) {
                                    customSnackBar('this_service_not_available'.tr);
                                  }
                                });

                                Get.back();
                              }
                            },
                            onEditPressed: () {
                              Get.toNamed(RouteHelper.getEditAddressRoute(address, false));
                            },
                            onRemovePressed: () {
                              if (Get.isSnackbarOpen) {
                                Get.back();
                              }
                              Get.dialog(
                                ConfirmationDialog(
                                  icon: Images.warning,
                                  description: 'are_you_sure_want_to_delete_address'.tr,
                                  onYesPressed: () {
                                    Navigator.of(context).pop();

                                    Get.dialog(
                                      const CustomLoader(),
                                      barrierDismissible: false,
                                    );

                                    locationController
                                        .deleteUserAddressByID(address)
                                        .then((response) {
                                      Get.back();
                                      customSnackBar(
                                        response.message!.tr.capitalizeFirst,
                                        type: ToasterMessageType.success,
                                      );
                                    });
                                  },
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                  )
                      : SizedBox(
                    height: Get.height * 0.6,
                    child: Center(
                      child: NoDataScreen(
                        text: 'no_address_found'.tr,
                        type: NoDataType.address,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        } else {
          return const Center(child: CircularProgressIndicator());
        }
      }),

      floatingActionButton:
      (!ResponsiveHelper.isDesktop(context) && Get.find<AuthController>().isLoggedIn())
          ? GestureDetector(
        onTap: () {
          Get.toNamed(RouteHelper.getAddAddressRoute(
              widget.fromPage == 'checkout'));
        },
        child: Container(
          height: Dimensions.addAddressHeight,
          width: Dimensions.addAddressWidth,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary,
            borderRadius: BorderRadius.circular(Dimensions.radiusExtraMoreLarge),
            boxShadow: Get.isDarkMode ? null : shadow,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.add, color: Colors.white, size: 20),
              const SizedBox(width: Dimensions.paddingSizeExtraSmall),
              Text(
                'add_new_address'.tr,
                style: robotoMedium.copyWith(
                  fontSize: Dimensions.fontSizeDefault,
                  color: Theme.of(context).primaryColorLight,
                ),
              ),
            ],
          ),
        ),
      )
          : null,
    );
  }
}